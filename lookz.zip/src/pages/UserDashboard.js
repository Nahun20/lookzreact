// UserDashboard.js
import React from 'react';

const UserDashboard = () => {
  return (
    <div>
      <h1>Bienvenido, Usuario</h1>
      <p>Aquí podrás ver tus productos, mensajes, etc.</p>
    </div>
  );
};

export default UserDashboard;
